from parser import Parser

def tokenizar(linea):
    linea = linea.replace(":=", " := ")
    return linea.split()

def probar():
    with open("pruebas.txt") as f:
        lineas = f.readlines()

    for i, linea in enumerate(lineas, 1):
        linea = linea.strip()
        if not linea:
            continue

        tokens = tokenizar(linea)
        parser = Parser(tokens)

        print(f"\nLinea {i}: {linea}")

        if parser.parse():
            print("ACEPTA")
        else:
            print("NO ACEPTA")

if __name__ == "__main__":
    probar()
