class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def actual(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def match(self, esperado):
        if self.actual() == esperado:
            self.pos += 1
        else:
            raise Exception(f"Error: se esperaba {esperado} y se encontró {self.actual()}")

    # <stmt> ::= <asig> | <cond>
    def stmt(self):
        if self.actual() == "when":
            self.cond()
        else:
            self.asig()

    # <asig> ::= ID := <expr>
    def asig(self):
        if self.actual().isalpha():
            self.pos += 1
            self.match(":=")
            self.expr()
        else:
            raise Exception("Error en asignación")

    # <cond> ::= when <expr> do <stmt> otherwise <stmt>
    def cond(self):
        self.match("when")
        self.expr()
        self.match("do")
        self.stmt()
        self.match("otherwise")
        self.stmt()

    # <expr> ::= ID | NUM
    def expr(self):
        if self.actual() and (self.actual().isdigit() or self.actual().isalpha()):
            self.pos += 1
        else:
            raise Exception("Error en expresión")

    def parse(self):
        try:
            self.stmt()
            return self.pos == len(self.tokens)
        except Exception as e:
            print(e)
            return False
